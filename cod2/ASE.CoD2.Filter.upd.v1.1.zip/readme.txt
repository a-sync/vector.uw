Updated ASE CoD2 Filter v1.1
by: Vector Akashi
===========================
USE:
Copy the 'filters.txt' into the main All-Seeing Eye folder. (C:\Program Files\The All-Seeing Eye\ by default)
===========================

This updated ASE filter will add extra version filter, updated map filter (with a lot of popular costum maps) and updated Punk Buster filter for CoD2.

===========================
FREE TO COPY.
---------------------------
(C) 2006 by Vector Akashi - I Know My Rights...
New versions, updates at: www.cod2-cfg.tk
Info, bug report, and support to: info @ cod2-cfg . tk