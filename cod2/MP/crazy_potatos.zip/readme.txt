Crazy Potatos [Fixed]
by: Vector Akashi
===========================
Potato Grenade Mod
description:
The mod will give players potatos in the place of grenades.
WARNING!These potatos are more dangerous then grenades ;)
---------------------------

-Cookable (3 sec)
-Uses cool explosion effect (based on ammosupply_exp)
-Larger hit damage, and hit radius than default grenades
-Larger throw radius
-Larger bounce
-Potato will explode immediately if you hit directly your enemy

Hard gameplay, more fun!
===========================
Voodoo Potatos Mod
description:
The mod will give players potatos in the place of smoke grenades.
WARNING!These potatos are magical voodoo potatos ;)
It causes hallucinations!
---------------------------

-The potato will drop one random model on the map (sometimes better for hiding)
 (16 available -more would overload the server)
-The model is shrinking constantly, as long as it vanish after 60 sec
 (check screenshots)
-Larger throw radius
-Larger bounce

Weird gameplay, more fun!
===========================
USE:
copy z_voodoo_potato.iwd or z_potatogrenade.iwd (wich you wont to use; or both) 
to your Call of Duty2\main folder

UNINSTALL:
delete z_voodoo_potato.iwd or z_potatogrenade.iwd 
from your Call of Duty2\main folder (wich you dont wont to use anymore)
===========================
FREE TO COPY.
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, bug report, any idea and support to: info@cod2-cfg.tk
www.cod2-cfg.tk