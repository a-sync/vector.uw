Reload Realism Mod v0.3
by: Vector Akashi
---------------------------
Realism mod for multiplayer.
===========================
USE:
copy zzz_reloadrealism.iwd to your Call of Duty2\main folder

UNINSTALL:
delete zzz_reloadrealism.iwd from your Call of Duty2\main folder
---------------------------

-You can only reload by double hiting your Use key (F for default) (by Snipers, Shotgun, Enfield and M1Garand you will get only a report about the number of bullets, or clips left), and so by reloading you will drop the bullets you left in your ammo clip
-By reloading, the number of remaining ammo clips or bullets will be reported
-You cant drop your current clip if you have no ammo left
-No ammo counter
-No weapon infos
-No stance displayer
-No crosshairs
-No death icons
-No friend icons
-No grenade indicators
-No health regeneration
-No killcam
-No death icons befor the names on scoreboard
-No team, or player score on HUD
-No objective indicators on the HUD (big 'A' or 'B' or flag...)
-No text writed by Quickmessages (only sound)
-No obituary message, or anything if someone was killed
-No mantle hints (climbover indicators)
-Realistic blood
-Only objectives showed on compass
-Shellshock realised
-Slower move speed
-Reduced melee damage
-Damage levels of weapons increased (shotgun damage radius and damage reduced)
-30 clip Thompson
-Cookable grenades
-Grenades throw lenght reduced
-66% chance for dead players to drop ammo or grenades or both
-The ammo dropped by dead soldiers is only the ammo from their weapon clips
-Weapon drop by hiting hands, and 66% chance by hiting Gun
-New grenade explosion effect
-Dust and Fog removed from maps (+20-30 FPS for players)
-Added Anti Exploit Fix
-Supported Gametypes: DM,TDM,SD,CTF,HQ

Search and Destroy
 -Bomb timer will be showed only for the attacking team
 -Only the bomb planter say's the "Bomb planted!" sound, and only in his local area
 -The compass will show always the two possible objective points ('A' and 'B')
 -Bomb planting and defusing time is based on the health of the player; from 5 to 15 sec (lower health = more shaking hands :D)
 -Only one bomb is added
 -One randomly selected player is the bomb carrier in every round (bomb will be dropped if the player is killed/disconnected/etc.)
 -Bomb can be picked up by team mates
 -No marking on the compass for the planted bomb
 -No sound by bomb planting or defusing
 -No ticking sound if bomb is planted
 -No bomb plant or defuse text on HUD in bomb area (only hand icon)
 -No bomb planted or defused print text for players
 -No glowing bomb model
 -New bomb explosion effect
 -Bomb explosion sound added
---------------------------

Credits: to bystander (www.after-hourz.com) and to the many helpful member at the IW Nation forums...

WANTED: for a new bomb icon on the hud (while holding the bomb), pls post it to me if you make one :)

[Settings will be optional in 1.0]
===========================
FREE TO COPY WITH CREDITS!
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, help, bug report, any idea and support to:
info@cod2-cfg.tk or check the NEW www.cod2-cfg.tk site.