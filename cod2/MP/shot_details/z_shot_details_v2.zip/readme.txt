Shot Details Mod v2
by: Vector Akashi
===========================

This mod will allow to tell the killer and the killed the Shot Details: distance between them in meters, and the hit location.

===========================
FREE TO COPY.
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, bug report, any idea and support to: info@cod2-cfg.tk
www.cod2-cfg.tk