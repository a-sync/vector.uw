Beam Tracer Mod
by: Vector Akashi
===========================

This mod will give a fire beam to the weapon bullets.

===========================
FREE TO COPY.
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, bug report, any idea and support to: info@cod2-cfg.tk
www.cod2-cfg.tk