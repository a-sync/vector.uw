ZoomInstaGib Mod v2
by: Vector Akashi
---------------------------
This is the CoD2 version copy, of the Unreal Tournament Mutator: Zoom InstaGib.
===========================
USE:
copy z_zoominstagib.iwd to your Call of Duty2\main folder

UNINSTALL:
delete z_zoominstagib.iwd from your Call of Duty2\main folder
---------------------------
By default:
-Only Zoom InstaGib selectable in menu
-M1Garand models for all teams (InstaGib rifle)
-InstaGib rifle is full auto
-Fixed crosshair
-Crosshair will not turn red if you aim enemy's
-One hit one kill shot
-Infinitie ammo
-Enlarged zooming
-Enlarged move speed
-No melee attack
-No partial reload
-No enemy marking red dots on the compass
-No Mg42 and 30cal turrets on maps
-No fraggrenade, or smokegrenade
-No secondary weapon (pistols)
-No ammo or grenade drop
-Blue beam by shoting
-Original UT InstaGib sound
-You shoot where you point from any range
-Supported Gametypes: DM,TDM,SD,CTF,HQ,HTF,LTS,RE

You can use extra settings, by adding these variables to your server config file:
(no is the default setting without any variable added)

//Allow MG42 and 30cal turrets on maps (0=no 1=yes)
set scr_allow_zig_turret "X"

//Allow some Frag Grenades (0=no 1-3=number of grenades)
set scr_allow_zig_frag "X"

//Allow one Smoke Grenade (0=no 1=yes)
set scr_allow_zig_smoke "X"

//Allow players to drop their ammo, and grenades after dying (0=no 1=yes)
set scr_allow_zig_drop "X"

//Allow to tell the killer and the killed the Shot Details: distance between them in meters, hit location (0=no 1=yes)
set scr_allow_zig_sd "X"
===========================
FREE TO COPY.
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, bug report, any idea and support to: info@cod2-cfg.tk
www.cod2-cfg.tk