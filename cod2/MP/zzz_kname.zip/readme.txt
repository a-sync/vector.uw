Kick that Name v1.1
by: Vector Akashi
===========================
USE:
copy zzz_kname.iwd to your (servers) Call of Duty2\main folder

UNINSTALL:
delete zzz_kname.iwd from your (servers) Call of Duty2\main folder
---------------------------

The mod kicks players if they have a certain name you set.

set kname1 "Unnamed Player"
set kname2 "consol"
set kname3 "j^3oe"
etc.

-you can add endless number of names beginning with 1 (kname1)
-you have to add them with the color codes
-add new variables (names) sequentially (eg.: kname4, kname5, kname6, etc.)

You can use the rcon to add names while the server is online.

Type '/rcon set kname Joe' to add the name 'Joe' to the list.
Type '/rcon set knameID 1' to add the name of the player with the ID 1.
(use '/rcon set knameID -1' to add all player names on the server)
Type '/rcon set knameDel Joe' to delet the name 'Joe' from the list.

The settings done via the rcon will be lost if the server restarts.
 -however the changes are in the logfile so you can copy paste them
  into the server config file if you want to

===========================
FREE TO COPY.
---------------------------
(C) 2006 by Vector Akashi - I Know My Rights...
New versions, updates at: www.cod2-cfg.tk
Info, bug report, and support to: info @ cod2-cfg . tk