No Dust Mod v2
updated by: Vector Akashi
---------------------------
This mod is based on the original zzz_nodustmod.iwd
The credits goes to the original scripter first...
===========================
USE:
copy zzz_nodustmod_v2.iwd to your Call of Duty2\main folder

UNINSTALL:
delete zzz_nodustmod_v2.iwd from your Call of Duty2\main folder
---------------------------
This mod will remove the Ambient stuff from the maps:
-fog, dust, smoke etc.

By using it, you can boost up your FPS (+20-40)

Works up to v1.3 servers.
===========================
FREE TO COPY.
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, help, bug report, any idea and support to:
info@cod2-cfg.tk or check the NEW www.cod2-cfg.tk site.