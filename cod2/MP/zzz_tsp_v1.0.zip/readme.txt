Team Score Protector v1.0
by: Vector Akashi
===========================
USE:
copy zzz_tsp.iwd to your (servers) Call of Duty2\main folder

UNINSTALL:
delete zzz_tsp.iwd from your (servers) Call of Duty2\main folder
---------------------------

The mod kicks players if they reach the score you set.

set vec_tsp "-5" // default score: -10

(if you type a higher score as -1,
the script will set the score to -10)

===========================
FREE TO COPY.
---------------------------
(C) 2006 by Vector Akashi - I Know My Rights...
New versions, updates at: www.cod2-cfg.tk
Info, bug report, and support to: info @ cod2-cfg . tk