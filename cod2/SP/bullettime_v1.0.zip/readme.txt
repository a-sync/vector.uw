Bullettime v1.0 - CoD2 Script
by: Vector Akashi
---------------------------
By using this script, you can get Bullettime effect in CoD2 Single Player. (like in Matrix or Max Payne)
===========================
Installing:
Unpack the zip into your Call of Duty 2 installation folder. ('C:\Program Files\Call of Duty 2\' by default)
  Open the 'vecbt.cfg' file in 'Call of Duty 2\main\' with notepad.
  Edit the key 'C' at line five, to whatever key you want to ('F' 'ALT' etc.) and save the file.
Use 'CoD2SP_bt.bat' to start the game.
===========================
In game hit the bullettime key ('C' by default) to start or stop Bulettime effect.
 -slows down the gamespeed massively (step-by-step)
 -shows all bullettracer while in bullettime

===========================
FREE TO COPY
---------------------------
(C) 2006 by Vector Akashi - I Know My Rights...
New versions, updates at: www.cod2-cfg.tk
Info, bug report, and support to: info @ cod2-cfg . tk