Chuck Norris Facts Quotes
by: Vector Akashi
---------------------------
This mod changes all victory and dead quotes to Chuck Norris fact's...
===========================
USE:
copy zzz_chucknorrisfacts.iwd to your Call of Duty2\main folder

UNINSTALL:
delete zzz_chucknorrisfacts.iwd from your Call of Duty2\main folder
===========================
FREE TO COPY.
---------------------------
Copyright 2006 by Vector Akashi - I Know My Rights...
Info, help, bug report, any idea and support to:
info@cod2-cfg.tk or check the NEW www.cod2-cfg.tk site.