No Dust Mod Single Player v1
by: Vector Akashi
===========================
USE:
copy zzz_nodustmod_sp_v1.iwd to your Call of Duty2\main folder

UNINSTALL:
delete zzz_nodustmod_sp_v1.iwd from your Call of Duty2\main folder
---------------------------

This mod will remove the Ambient stuff from the Single Player maps:
-fog, dust, smoke etc.

By using it, you can boost up your FPS (+20-40)

Works up to v1.3 patch

===========================
FREE TO COPY.
---------------------------
(C) 2006 by Vector Akashi - I Know My Rights...
New versions, updates at: www.cod2-cfg.tk
Info, bug report, and support to: info @ cod2-cfg . tk